import 'package:to_do_list/todo.dart';
import 'package:provider/provider.dart';
import 'package:flutter/material.dart';

class TodoProvider with ChangeNotifier {
  List<ToDo> todos = [];

  List<ToDo> get todoList => todos;

  // List<ToDo> getTodos() {
  //   List<ToDo> todoList = todos;
  //   return todoList;
  // }

  addTodo(ToDo todo) {
    todos.add(todo);
    notifyListeners();
  }

  removeTodo(int index) {
    todos.removeAt(index);
    notifyListeners();
  }

  toggleisDone(int index) {
    todoList[index].isDone = !todoList[index].isDone;
    notifyListeners();
  }
}
