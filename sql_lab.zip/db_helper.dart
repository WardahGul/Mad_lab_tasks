// import 'package:flutter/material.dart';
// import 'package:notes_app/note.dart';
// import 'package:path/path.dart';
// import 'package:sqflite/sqflite.dart';

// class DbHelper {
//   Database? _database;
//   final String tablename ="notes";


// Future<Database> get database async {
//   if (_database!= null) {
//     return _database!;
//   } else {
//     _database = await initDb();
//     return _database!;
//   }
// }

// Future<Database> initDb() async {
//   final dbpath = await getDatabasesPath();
//   final not_db_path = join(dbpath, "notes.db");

//   return await openDatabase(
//     not_db_path,
//     version: 1,
//     onCreate: (db, version) {
//       db.execute("CREATE TABLE $tablename(id INTEGER PRIM,)");
//     },
//   );
// }

// insert(Note note) async {
//   final db = await database;
//   await db.insert(
//     tablename,
//     {
//       "id": note.id,
//       "title": note.title,
//       "content": note.description,
//     },
     
//   );
// }

// delete(int id) async {
//   final db = await database;
//   await db.delete(tablename, where: "id = ?", whereArgs: [id]);
// }
// }


import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:notes_app/note.dart';

class Dbhelper {
  Database? _database;
  Future<Database?> get database async {
    if (_database != null) {
      return _database;
    } else {
      _database = await initDb();
      return _database;
    }
  }

  Future<Database> initDb() async {
    final dbpath = await getDatabasesPath();
    final note_db_path = join(dbpath, 'not.db');
    final db = openDatabase(note_db_path, version: 1, onCreate: ((db, version) {
      db.execute(
          'CREATE TABLE notes(id INTEGER PRIMARY KEY, title TEXT, content TEXT)');
    }));
    return db;
  }

  insert(Note note) async {
    final db = await database;
    await db!.insert('notes',
        {'id': note.id, 'title': note.title, 'content': note.description},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  update(Note note) async {
    final db = await database;
    await db!.update(
      'notes',
      {'id': note.id, 'title': note.title, 'content': note.description},
      where: "id = ?",
    );
  }

  delete(int id) async {
    final db = await database;
    await db!.delete(
      'notes',
      where: "id = ?",
      whereArgs: [id],
    );

    Future<List<Map<String, dynamic>>> quaryAll() async {
      final db = await database;
      return db!.query('notes');
    }
  }

  quaryAll() {}
}
