import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:firebase_02/auth_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.amber,
        // useMaterial3: false,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final em = TextEditingController();
  final pw = TextEditingController();
  final AuthService _auth = AuthService();

  signUp() async {
    final User? user = await _auth.SignUP(em.text, pw.text);
    if (user != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("signup successfull")));
    }
  }

  signin() async {
    final User? user = await _auth.LogIN(em.text, pw.text);
    if (user != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("login successfull")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("my app")),
      body: Form(
        child: Column(children: [
          TextField(
            controller: em,
            decoration: const InputDecoration(
              labelText: 'Email',
              hintText: 'Enter your email',
              border: OutlineInputBorder(),
            ),
          ),
          TextField(
            controller: pw,
            decoration: const InputDecoration(
              labelText: 'password',
              hintText: 'Enter your password',
              border: OutlineInputBorder(),
            ),
            obscureText: true,
          ),
          TextField(
            controller: em,
            decoration: const InputDecoration(
              labelText: 'Name',
              hintText: 'Enter your name',
              border: OutlineInputBorder(),
            ),
          ),
          ElevatedButton(onPressed: signin, child: Text("login")),
          ElevatedButton(onPressed: signUp, child: Text("Signup")),
        ]),
      ),
    );
  }
}
