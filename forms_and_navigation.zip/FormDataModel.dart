class FormDataModel {
  final String name;
  final String email;
  final String Gender;
  String dob;

  FormDataModel(
      {required this.name,
      required this.email,
      required this.Gender,
      required this.dob});
}
